
//
// File:    hello.cpp
// Purpose: prints hello world
// Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
//
// $Id$
//

#include <iostream>
using namespace std;

main()
{
	cout << "Hello World.\n";
}

// eof 
